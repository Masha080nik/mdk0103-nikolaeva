public class GiftIncome extends Income {
    private boolean isFromCloseRelative;

    public GiftIncome(String name, double amount, boolean isFromCloseRelative) {
        super(name, amount, 13.0);
        this.isFromCloseRelative = isFromCloseRelative;
    }

    public boolean isFromCloseRelative() {
        return isFromCloseRelative;
    }

    public void setFromCloseRelative(boolean fromCloseRelative) {
        isFromCloseRelative = fromCloseRelative;
    }

    @Override
    public double calculateTax() {
        if (isFromCloseRelative) {
            return 0; // Подарки от близких родственников не облагаются налогом
        }
        return super.calculateTax();
    }

    @Override
    public String getDescription() {
        return "Получение в подарок: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}