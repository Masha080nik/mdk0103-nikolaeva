public class Main {
    public static void main(String[] args) {
        // Создаем калькулятор для Иванова Ивана
        TaxCalculator taxCalc = new TaxCalculator("Иванов Иван Иванович");

        // Добавляем доходы
        System.out.println("Добавление доходов...");

        // Основная работа
        SalaryIncome mainJob = new SalaryIncome("ООО Ромашка", 600000, true);
        taxCalc.addIncome(mainJob);

        // Дополнительная работа
        SalaryIncome extraJob = new SalaryIncome("ИП Петров", 120000, false);
        taxCalc.addIncome(extraJob);

        // Авторское вознаграждение
        RoyaltyIncome royalty = new RoyaltyIncome("Книга 'Программирование для всех'", 50000);
        taxCalc.addIncome(royalty);

        // Продажа имущества (квартира, владение менее 3 лет)
        PropertySaleIncome apartmentSale = new PropertySaleIncome("Продажа квартиры", 2500000, false);
        taxCalc.addIncome(apartmentSale);

        // Продажа имущества (машина, владение более 3 лет)
        PropertySaleIncome carSale = new PropertySaleIncome("Продажа автомобиля", 500000, true);
        taxCalc.addIncome(carSale);

        // Подарок от неблизкого родственника
        GiftIncome gift = new GiftIncome("Денежный подарок от друга", 100000, false);
        taxCalc.addIncome(gift);

        // Подарок от близкого родственника
        GiftIncome giftFromRelative = new GiftIncome("Подарок от брата", 50000, true);
        taxCalc.addIncome(giftFromRelative);

        // Перевод из-за границы
        ForeignTransferIncome transfer = new ForeignTransferIncome("Перевод из США", 200000);
        taxCalc.addIncome(transfer);

        // Материальная помощь
        FinancialAssistance assistance = new FinancialAssistance("Матпомощь от работодателя", 5000);
        taxCalc.addIncome(assistance);

        // Добавляем льготы
        System.out.println("Добавление льгот...");

        // Льгота на двоих детей
        ChildBenefit childBenefit = new ChildBenefit(2);
        taxCalc.addBenefit(childBenefit);

        // Печатаем отчет
        taxCalc.printTaxReport();

        // Демонстрация работы equals()
        System.out.println("\nДЕМОНСТРАЦИЯ РАБОТЫ equals():");
        System.out.println("------------------------------------------");
        SalaryIncome job1 = new SalaryIncome("ООО Тест", 100000, true);
        SalaryIncome job2 = new SalaryIncome("ООО Тест", 100000, true);
        SalaryIncome job3 = new SalaryIncome("ООО Тест", 150000, true);

        System.out.println("job1.equals(job2): " + job1.equals(job2) + " (должно быть true)");
        System.out.println("job1.equals(job3): " + job1.equals(job3) + " (должно быть false)");

        // Демонстрация работы toString()
        System.out.println("\nДЕМОНСТРАЦИЯ РАБОТЫ toString():");
        System.out.println("------------------------------------------");
        System.out.println(mainJob);
        System.out.println(royalty);
        System.out.println(assistance);

        // Демонстрация работы сеттеров
        System.out.println("\nДЕМОНСТРАЦИЯ РАБОТЫ СЕТТЕРОВ:");
        System.out.println("------------------------------------------");
        System.out.println("До изменения: " + childBenefit);
        childBenefit.setNumberOfChildren(3);
        System.out.println("После изменения (3 детей): " + childBenefit);
    }
}