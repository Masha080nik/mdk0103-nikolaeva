public class SalaryIncome extends Income {
    private boolean isMainJob;

    public SalaryIncome(String name, double amount, boolean isMainJob) {
        super(name, amount, 13.0);
        this.isMainJob = isMainJob;
    }

    public boolean isMainJob() {
        return isMainJob;
    }

    public void setMainJob(boolean mainJob) {
        isMainJob = mainJob;
    }

    @Override
    public double calculateTax() {
        return super.calculateTax();
    }

    @Override
    public String getDescription() {
        return (isMainJob ? "Основная" : "Дополнительная") + " работа: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}