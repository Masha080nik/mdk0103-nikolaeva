public class ForeignTransferIncome extends Income {
    public ForeignTransferIncome(String name, double amount) {
        super(name, amount, 13.0);
    }

    @Override
    public String getDescription() {
        return "Перевод из-за границы: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}