public class RoyaltyIncome extends Income {
    public RoyaltyIncome(String name, double amount) {
        super(name, amount, 13.0);
    }

    @Override
    public String getDescription() {
        return "Авторское вознаграждение: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}