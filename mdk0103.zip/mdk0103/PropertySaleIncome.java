public class PropertySaleIncome extends Income {
    private boolean isOwnedMoreThan3Years;

    public PropertySaleIncome(String name, double amount, boolean isOwnedMoreThan3Years) {
        super(name, amount, 13.0);
        this.isOwnedMoreThan3Years = isOwnedMoreThan3Years;
    }

    public boolean isOwnedMoreThan3Years() {
        return isOwnedMoreThan3Years;
    }

    public void setOwnedMoreThan3Years(boolean ownedMoreThan3Years) {
        isOwnedMoreThan3Years = ownedMoreThan3Years;
    }

    @Override
    public double calculateTax() {
        if (isOwnedMoreThan3Years) {
            return 0; // Освобождается от налога
        }
        return super.calculateTax();
    }

    @Override
    public String getDescription() {
        return "Продажа имущества: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}