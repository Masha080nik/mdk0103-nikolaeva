public interface Taxable {
    double calculateTax();
    String getDescription();
}