public class FinancialAssistance extends Income {
    public FinancialAssistance(String name, double amount) {
        super(name, amount, 0.0); // Матпомощь не облагается налогом до 4000 руб
    }

    @Override
    public double calculateTax() {
        // Материальная помощь до 4000 руб в год не облагается налогом
        if (amount <= 4000) {
            return 0;
        }
        // Свыше 4000 руб облагается по ставке 13%
        return (amount - 4000) * 0.13;
    }

    @Override
    public String getDescription() {
        return "Материальная помощь: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}