import java.util.*;

public class TaxCalculator {
    private List<Income> incomes;
    private List<TaxBenefit> benefits;
    private String personName;

    public TaxCalculator(String personName) {
        this.personName = personName;
        this.incomes = new ArrayList<>();
        this.benefits = new ArrayList<>();
    }

    public void addIncome(Income income) {
        incomes.add(income);
    }

    public void addBenefit(TaxBenefit benefit) {
        benefits.add(benefit);
    }

    public double calculateTotalTax() {
        double totalTax = 0;
        for (Income income : incomes) {
            totalTax += income.calculateTax();
        }
        return totalTax;
    }

    public double calculateTotalBenefits() {
        double totalBenefits = 0;
        for (TaxBenefit benefit : benefits) {
            totalBenefits += benefit.calculateBenefit();
        }
        return totalBenefits;
    }

    public List<Income> getIncomesSortedByTax() {
        List<Income> sortedIncomes = new ArrayList<>(incomes);
        Collections.sort(sortedIncomes,
                (i1, i2) -> Double.compare(i2.calculateTax(), i1.calculateTax()));
        return sortedIncomes;
    }

    public void printTaxReport() {
        System.out.println("==========================================");
        System.out.println("НАЛОГОВЫЙ ОТЧЕТ ДЛЯ: " + personName);
        System.out.println("==========================================");

        System.out.println("\nДОХОДЫ И НАЧИСЛЕННЫЕ НАЛОГИ:");
        System.out.println("------------------------------------------");
        for (Income income : incomes) {
            System.out.println(income);
        }

        System.out.println("\nЛЬГОТЫ:");
        System.out.println("------------------------------------------");
        for (TaxBenefit benefit : benefits) {
            System.out.println(benefit);
        }

        System.out.println("\nИТОГИ:");
        System.out.println("------------------------------------------");
        System.out.printf("Общая сумма налогов: %.2f руб.\n", calculateTotalTax());
        System.out.printf("Общая сумма льгот: %.2f руб.\n", calculateTotalBenefits());

        System.out.println("\nНАЛОГИ, ОТСОРТИРОВАННЫЕ ПО УБЫВАНИЮ:");
        System.out.println("------------------------------------------");
        List<Income> sortedIncomes = getIncomesSortedByTax();
        for (int i = 0; i < sortedIncomes.size(); i++) {
            Income income = sortedIncomes.get(i);
            System.out.printf("%d. %s - налог: %.2f руб.\n",
                    i + 1, income.getDescription(), income.calculateTax());
        }
        System.out.println("==========================================");
    }

    @Override
    public String toString() {
        return String.format("TaxCalculator{personName='%s', incomes=%d, benefits=%d}",
                personName, incomes.size(), benefits.size());
    }
}