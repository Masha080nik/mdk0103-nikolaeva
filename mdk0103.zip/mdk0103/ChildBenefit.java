public class ChildBenefit extends TaxBenefit {
    private int numberOfChildren;

    public ChildBenefit(int numberOfChildren) {
        super("На детей", numberOfChildren * 1400); // 1400 руб на каждого ребенка
        this.numberOfChildren = numberOfChildren;
    }

    public int getNumberOfChildren() {
        return numberOfChildren;
    }

    public void setNumberOfChildren(int numberOfChildren) {
        this.numberOfChildren = numberOfChildren;
        setAmount(numberOfChildren * 1400);
    }

    @Override
    public double calculateBenefit() {
        return getAmount(); // Сумма, уменьшающая налогооблагаемую базу
    }

    @Override
    public String toString() {
        return String.format("Льгота на детей: %d детей, сумма льготы=%.2f",
                numberOfChildren, getAmount());
    }
}