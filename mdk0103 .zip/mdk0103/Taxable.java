public interface Taxable {
    double calculateTax();
    double getTaxableAmount();  // Сумма, облагаемая НДФЛ (для прогрессивной шкалы 2026)
    String getDescription();
}