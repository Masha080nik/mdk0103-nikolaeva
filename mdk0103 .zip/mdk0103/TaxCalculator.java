import java.util.*;

public class TaxCalculator {
    private List<Income> incomes;
    private List<TaxBenefit> benefits;
    private String personName;

    public TaxCalculator(String personName) {
        this.personName = personName;
        this.incomes = new ArrayList<>();
        this.benefits = new ArrayList<>();
    }

    public void addIncome(Income income) {
        incomes.add(income);
    }

    public void addBenefit(TaxBenefit benefit) {
        benefits.add(benefit);
    }

    /** Сумма облагаемых доходов (включая подарки от неблизких — НДФЛ) */
    public double getTotalTaxableIncome() {
        double sum = 0;
        for (Income income : incomes) {
            sum += income.getTaxableAmount();
        }
        return sum;
    }

    /** Налоговая база с учётом льгот */
    public double getTaxBase() {
        return Math.max(0, getTotalTaxableIncome() - calculateTotalBenefits());
    }

    /** Итоговый налог по прогрессивной шкале НДФЛ 2026 */
    public double calculateTotalTax() {
        return NDFLRates2026.calculateProgressiveTax(getTaxBase());
    }

    /** Налог, приходящийся на данный доход (пропорционально облагаемой сумме) */
    public double getTaxShare(Income income) {
        double totalTaxable = getTotalTaxableIncome();
        if (totalTaxable <= 0) return 0;
        double share = income.getTaxableAmount() / totalTaxable;
        return share * calculateTotalTax();
    }

    /** Эффективная ставка для данного дохода */
    public double getEffectiveRate(Income income) {
        double taxable = income.getTaxableAmount();
        if (taxable <= 0) return 0;
        return getTaxShare(income) / taxable * 100;
    }

    public double calculateTotalBenefits() {
        double totalBenefits = 0;
        for (TaxBenefit benefit : benefits) {
            totalBenefits += benefit.calculateBenefit();
        }
        return totalBenefits;
    }

    public List<Income> getIncomesSortedByTax() {
        List<Income> sortedIncomes = new ArrayList<>(incomes);
        Collections.sort(sortedIncomes,
                (i1, i2) -> Double.compare(getTaxShare(i2), getTaxShare(i1)));
        return sortedIncomes;
    }

    public void printTaxReport() {
        System.out.println("==========================================");
        System.out.println("НАЛОГОВЫЙ ОТЧЕТ ДЛЯ: " + personName + " (2026 г.)");
        System.out.println("==========================================");

        System.out.println("\nДОХОДЫ И НАЧИСЛЕННЫЕ НАЛОГИ (прогрессивная шкала 2026):");
        System.out.println("------------------------------------------");
        for (Income income : incomes) {
            double tax = getTaxShare(income);
            double rate = getEffectiveRate(income);
            System.out.printf("%s сумма=%.2f, облагаемая=%.2f, ставка=%.1f%%, налог=%.2f\n",
                    income.getDescription(), income.getAmount(), income.getTaxableAmount(), rate, tax);
        }

        System.out.println("\nЛЬГОТЫ:");
        System.out.println("------------------------------------------");
        for (TaxBenefit benefit : benefits) {
            System.out.println(benefit);
        }

        System.out.println("\nИТОГИ:");
        System.out.println("------------------------------------------");
        System.out.printf("Облагаемые доходы: %.2f руб.\n", getTotalTaxableIncome());
        System.out.printf("Налоговая база (доходы − вычеты): %.2f руб.\n", getTaxBase());
        System.out.printf("НДФЛ (прогрессивная шкала 13–22%%): %.2f руб.\n", calculateTotalTax());
        System.out.printf("Общая сумма льгот: %.2f руб.\n", calculateTotalBenefits());

        System.out.println("\nНАЛОГИ, ОТСОРТИРОВАННЫЕ ПО УБЫВАНИЮ:");
        System.out.println("------------------------------------------");
        List<Income> sortedIncomes = getIncomesSortedByTax();
        for (int i = 0; i < sortedIncomes.size(); i++) {
            Income income = sortedIncomes.get(i);
            System.out.printf("%d. %s - налог: %.2f руб.\n",
                    i + 1, income.getDescription(), getTaxShare(income));
        }
        System.out.println("==========================================");
    }

    @Override
    public String toString() {
        return String.format("TaxCalculator{personName='%s', incomes=%d, benefits=%d}",
                personName, incomes.size(), benefits.size());
    }
}