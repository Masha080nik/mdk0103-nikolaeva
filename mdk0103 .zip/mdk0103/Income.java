import java.util.Objects;

public abstract class Income implements Taxable {
    protected String name;
    protected double amount;
    protected double taxRate;

    public Income(String name, double amount, double taxRate) {
        this.name = name;
        this.amount = amount;
        this.taxRate = taxRate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    @Override
    public double calculateTax() {
        return amount * taxRate / 100;
    }

    @Override
    public double getTaxableAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return String.format("%s: сумма=%.2f, облагаемая=%.2f",
                name, amount, getTaxableAmount());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Income income = (Income) o;
        return Double.compare(income.amount, amount) == 0 &&
                Double.compare(income.taxRate, taxRate) == 0 &&
                Objects.equals(name, income.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, amount, taxRate);
    }
}