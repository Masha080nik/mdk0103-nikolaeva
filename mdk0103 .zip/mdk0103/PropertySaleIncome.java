public class PropertySaleIncome extends Income {
    // В 2026 г.: для большинства объектов — 5 лет; для наследства, дара, единственного жилья и др. — 3 года
    private boolean isOwnedMoreThan3Years;

    public PropertySaleIncome(String name, double amount, boolean isOwnedMoreThan3Years) {
        super(name, amount, 0);  // Ставка — прогрессивная шкала НДФЛ 2026
        this.isOwnedMoreThan3Years = isOwnedMoreThan3Years;
    }

    public boolean isOwnedMoreThan3Years() {
        return isOwnedMoreThan3Years;
    }

    public void setOwnedMoreThan3Years(boolean ownedMoreThan3Years) {
        isOwnedMoreThan3Years = ownedMoreThan3Years;
    }

    @Override
    public double getTaxableAmount() {
        return isOwnedMoreThan3Years ? 0 : amount;
    }

    @Override
    public double calculateTax() {
        return 0;  // Налог считается в TaxCalculator
    }

    @Override
    public String getDescription() {
        return "Продажа имущества: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}