public class FinancialAssistance extends Income {
    // Материальная помощь по общим основаниям: до 4000 руб/год не облагается НДФЛ (2026)
    private static final double NON_TAXABLE_LIMIT = 4000;

    public FinancialAssistance(String name, double amount) {
        super(name, amount, 0.0);
    }

    @Override
    public double getTaxableAmount() {
        return amount <= NON_TAXABLE_LIMIT ? 0 : (amount - NON_TAXABLE_LIMIT);
    }

    @Override
    public double calculateTax() {
        return 0;  // Налог считается в TaxCalculator по прогрессивной шкале
    }

    @Override
    public String getDescription() {
        return "Материальная помощь: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}