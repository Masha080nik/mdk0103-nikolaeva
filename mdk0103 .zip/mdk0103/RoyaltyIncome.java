public class RoyaltyIncome extends Income {
    public RoyaltyIncome(String name, double amount) {
        super(name, amount, 0);  // Прогрессивная шкала НДФЛ 2026
    }

    @Override
    public double calculateTax() {
        return 0;  // Налог считается в TaxCalculator
    }

    @Override
    public String getDescription() {
        return "Авторское вознаграждение: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}