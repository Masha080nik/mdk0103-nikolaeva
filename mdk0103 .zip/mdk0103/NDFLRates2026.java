/**
 * Прогрессивная шкала НДФЛ 2026 (ст. 224 НК РФ).
 * Пороги: до 2.4 млн — 13%, 2.4–5 млн — 15%, 5–20 млн — 18%, 20–50 млн — 20%, свыше 50 млн — 22%.
 */
public class NDFLRates2026 {
    private static final double LIMIT_1 = 2_400_000;
    private static final double LIMIT_2 = 5_000_000;
    private static final double LIMIT_3 = 20_000_000;
    private static final double LIMIT_4 = 50_000_000;
    private static final double RATE_1 = 0.13;
    private static final double RATE_2 = 0.15;
    private static final double RATE_3 = 0.18;
    private static final double RATE_4 = 0.20;
    private static final double RATE_5 = 0.22;

    /** Рассчитывает налог по прогрессивной шкале (2026) */
    public static double calculateProgressiveTax(double taxableBase) {
        if (taxableBase <= 0) return 0;
        double tax = 0;
        double remaining = taxableBase;

        if (remaining > LIMIT_4) {
            tax += (remaining - LIMIT_4) * RATE_5;
            remaining = LIMIT_4;
        }
        if (remaining > LIMIT_3) {
            tax += (remaining - LIMIT_3) * RATE_4;
            remaining = LIMIT_3;
        }
        if (remaining > LIMIT_2) {
            tax += (remaining - LIMIT_2) * RATE_3;
            remaining = LIMIT_2;
        }
        if (remaining > LIMIT_1) {
            tax += (remaining - LIMIT_1) * RATE_2;
            remaining = LIMIT_1;
        }
        tax += remaining * RATE_1;
        return tax;
    }
}
