public class Main {
    public static void main(String[] args) {
        // Создаем калькулятор для Иванова Ивана
        TaxCalculator taxCalc = new TaxCalculator("Иванов Иван Иванович");

        // Добавляем доходы
        System.out.println("Добавление доходов...");

        // Основная работа (~100 000 руб/мес, средняя по РФ 2026)
        SalaryIncome mainJob = new SalaryIncome("ООО Ромашка", 1_200_000, true);
        taxCalc.addIncome(mainJob);

        // Подработка по ГПД
        SalaryIncome extraJob = new SalaryIncome("ИП Петров", 240_000, false);
        taxCalc.addIncome(extraJob);

        // Авторское вознаграждение (разовое за книгу)
        RoyaltyIncome royalty = new RoyaltyIncome("Книга 'Программирование для всех'", 75_000);
        taxCalc.addIncome(royalty);

        // Продажа квартиры (владение менее 5 лет — облагается)
        PropertySaleIncome apartmentSale = new PropertySaleIncome("Продажа квартиры", 4_500_000, false);
        taxCalc.addIncome(apartmentSale);

        // Продажа авто (владение более 5 лет — не облагается)
        PropertySaleIncome carSale = new PropertySaleIncome("Продажа автомобиля", 550_000, true);
        taxCalc.addIncome(carSale);

        // Подарок от друга (облагается НДФЛ)
        GiftIncome gift = new GiftIncome("Денежный подарок от друга", 180_000, false);
        taxCalc.addIncome(gift);

        // Подарок от брата (близкий родственник — не облагается)
        GiftIncome giftFromRelative = new GiftIncome("Подарок от брата", 150_000, true);
        taxCalc.addIncome(giftFromRelative);

        // Перевод из-за границы
        ForeignTransferIncome transfer = new ForeignTransferIncome("Перевод из США", 120_000);
        taxCalc.addIncome(transfer);

        // Материальная помощь (первые 4 000 руб/год не облагаются)
        FinancialAssistance assistance = new FinancialAssistance("Матпомощь от работодателя", 8_000);
        taxCalc.addIncome(assistance);

        // Добавляем льготы
        System.out.println("Добавление льгот...");

        // Льгота на двоих детей
        ChildBenefit childBenefit = new ChildBenefit(2);
        taxCalc.addBenefit(childBenefit);

        // Печатаем отчет
        taxCalc.printTaxReport();

        // Демонстрация работы equals()
        System.out.println("\nДЕМОНСТРАЦИЯ РАБОТЫ equals():");
        System.out.println("------------------------------------------");
        SalaryIncome job1 = new SalaryIncome("ООО Тест", 100_000, true);
        SalaryIncome job2 = new SalaryIncome("ООО Тест", 100_000, true);
        SalaryIncome job3 = new SalaryIncome("ООО Тест", 120_000, true);

        System.out.println("job1.equals(job2): " + job1.equals(job2) + " (должно быть true)");
        System.out.println("job1.equals(job3): " + job1.equals(job3) + " (должно быть false)");

        // Демонстрация работы toString()
        System.out.println("\nДЕМОНСТРАЦИЯ РАБОТЫ toString():");
        System.out.println("------------------------------------------");
        System.out.println(mainJob);
        System.out.println(royalty);
        System.out.println(assistance);

        // Демонстрация работы сеттеров
        System.out.println("\nДЕМОНСТРАЦИЯ РАБОТЫ СЕТТЕРОВ:");
        System.out.println("------------------------------------------");
        System.out.println("До изменения: " + childBenefit);
        childBenefit.setNumberOfChildren(3);
        System.out.println("После изменения (3 детей): " + childBenefit);
    }
}