public class SalaryIncome extends Income {
    private boolean isMainJob;

    public SalaryIncome(String name, double amount, boolean isMainJob) {
        super(name, amount, 0);  // Прогрессивная шкала НДФЛ 2026
        this.isMainJob = isMainJob;
    }

    public boolean isMainJob() {
        return isMainJob;
    }

    public void setMainJob(boolean mainJob) {
        isMainJob = mainJob;
    }

    @Override
    public double calculateTax() {
        return 0;  // Налог считается в TaxCalculator
    }

    @Override
    public String getDescription() {
        return (isMainJob ? "Основная" : "Дополнительная") + " работа: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}