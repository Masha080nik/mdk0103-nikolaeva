public class ForeignTransferIncome extends Income {
    public ForeignTransferIncome(String name, double amount) {
        super(name, amount, 0);  // Прогрессивная шкала НДФЛ 2026
    }

    @Override
    public double calculateTax() {
        return 0;  // Налог считается в TaxCalculator
    }

    @Override
    public String getDescription() {
        return "Перевод из-за границы: " + getName();
    }

    @Override
    public String toString() {
        return getDescription() + " " + super.toString();
    }
}